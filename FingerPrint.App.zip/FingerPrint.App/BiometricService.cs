﻿using FingerPrint.Core;
using System.IO;
using System.ServiceModel.Web;
using System.Text;
using System.Web.Script.Serialization;

namespace FingerPrint.App
{

    public class BiometricService : IBiometricService
    {
        public Stream FingerCapture()
        {
            try
            {
                var capturedData = BiometricServices.FingerCapture();
                WebOperationContext.Current.OutgoingResponse.ContentType = "application/json; charset=utf-8";
                string capturedJsonData = new JavaScriptSerializer().Serialize(capturedData);
                byte[] capturedByteArray = Encoding.UTF8.GetBytes(capturedJsonData);

                return new MemoryStream(capturedByteArray);
            }
            catch (System.Exception ex)
            {
                WebOperationContext.Current.OutgoingResponse.ContentType = "application/json; charset=utf-8";
                return new MemoryStream(Encoding.UTF8.GetBytes(new JavaScriptSerializer().Serialize(ex.Message)));
            }

        }

    }
}
