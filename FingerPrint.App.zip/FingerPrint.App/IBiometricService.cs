﻿using System.IO;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Web.Script.Services;

namespace FingerPrint.App
{

    [ServiceContract]
    public interface IBiometricService
    {
        [OperationContract]
        [WebInvoke(UriTemplate = "/finger-capture", Method = "GET", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json)]
        [ScriptMethod(ResponseFormat = ResponseFormat.Json)]
        Stream FingerCapture();
    }
}
