﻿using System;
using System.IO;
using System.ServiceModel.Web;
using System.Windows.Forms;

namespace FingerPrint.App
{
    internal static class Program
    {
        private static WebServiceHost Host;

        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            Directory.SetCurrentDirectory(Path.Combine(Application.StartupPath, "Lib"));

            Program.Host = new WebServiceHost(typeof(BiometricService), new Uri("http://localhost:8200"));
            Program.Host.Open();
            Application.Run(new Form1());
            Program.Host.Close();
        }
    }
}
